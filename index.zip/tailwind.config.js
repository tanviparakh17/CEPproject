module.exports = {
  content: [
    "./src/**/*.{html,js,jsx,ts,tsx}", // Make sure to adjust based on your project structure
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};

